(() => {
const $ = id => document.getElementById(id);
const todayKey = () => new Date().toLocaleDateString('en-CA');
const datePretty = d => new Date(d+'T12:00:00').toLocaleDateString(undefined,{weekday:'short',month:'short',day:'numeric'});
const habits = [
  {id:'communication',title:'Communication & public speaking',desc:'Speak for 2 minutes and review',icon:'🎤'},
  {id:'french',title:'French practice',desc:'5 words + listening + speaking',icon:'🇫🇷'},
  {id:'coding',title:'C programming + DSA',desc:'Solve one problem or revise a concept',icon:'⌘'},
  {id:'calisthenics',title:'Calisthenics',desc:'Strength practice or planned recovery',icon:'✦'},
  {id:'running',title:'Running',desc:'Easy run, run-walk, or planned recovery',icon:'↗'}
];
const STORE='levelUpDataV1';
let data = load();
let timerInterval=null, timerRemaining=25*60, timerTotal=25*60, timerEnd=null;
let deferredInstallPrompt=null;
function load(){try{return JSON.parse(localStorage.getItem(STORE))||{days:{},journal:{},workouts:{},focusMinutes:0,reminder:null}}catch(e){return {days:{},journal:{},workouts:{},focusMinutes:0,reminder:null}}}
function save(){localStorage.setItem(STORE,JSON.stringify(data));}
function dayData(key=todayKey()){if(!data.days[key])data.days[key]={};return data.days[key]}
function toast(msg){const el=$('toast');el.textContent=msg;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),2300)}
function renderHabits(){
 const d=dayData();$('habitList').innerHTML='';
 habits.forEach(h=>{
  const done=!!d[h.id], row=document.createElement('label');row.className='habit-item'+(done?' done':'');
  row.innerHTML=`<input class="habit-check" type="checkbox" ${done?'checked':''} aria-label="Complete ${h.title}"><span class="habit-icon">${h.icon}</span><span class="habit-copy"><strong>${h.title}</strong><small>${h.desc}</small></span>`;
  row.querySelector('input').addEventListener('change',e=>{dayData()[h.id]=e.target.checked;save();renderAll();});
  $('habitList').appendChild(row);
 });
}
function renderHeader(){
 const d=dayData(),done=habits.filter(h=>d[h.id]).length, pct=Math.round(done/habits.length*100);
 $('percent').textContent=pct+'%';$('progressRing').style.background=`conic-gradient(var(--blue) ${pct*3.6}deg,#e8eaff 0deg)`;
 $('todayLabel').textContent=new Date().toLocaleDateString(undefined,{weekday:'long',month:'long',day:'numeric'}).toUpperCase();
 $('datePill').textContent=new Date().toLocaleDateString(undefined,{month:'short',day:'numeric'});
 ['Calisthenics','Running'].forEach(w=>{$('status-'+w).textContent=data.workouts[todayKey()]?.[w]?'Logged today':'Not logged';});
}
function streak(){
 const keys=Object.keys(data.days).sort().reverse();let count=0,d=new Date();d.setHours(12,0,0,0);
 // Streak counts days with at least one completed habit; today may be incomplete.
 if(!(data.days[todayKey()]&&Object.values(data.days[todayKey()]).some(Boolean)))d.setDate(d.getDate()-1);
 for(let i=0;i<370;i++){const k=d.toLocaleDateString('en-CA');if(data.days[k]&&Object.values(data.days[k]).some(Boolean)){count++;d.setDate(d.getDate()-1)}else break;}
 return count;
}
function renderProgress(){
 let done=0;Object.values(data.days).forEach(d=>done+=habits.filter(h=>d[h.id]).length);
 $('streakValue').textContent=streak();$('doneValue').textContent=done;$('focusValue').textContent=(data.focusMinutes||0)+'m';$('journalValue').textContent=Object.keys(data.journal).length;
 const days=[];for(let i=6;i>=0;i--){let d=new Date();d.setDate(d.getDate()-i);const key=d.toLocaleDateString('en-CA');days.push({key,label:d.toLocaleDateString(undefined,{weekday:'short'}),n:habits.filter(h=>data.days[key]?.[h.id]).length});}
 $('weekChart').innerHTML=days.map(x=>`<div class="day-bar-wrap"><div class="day-bar ${x.n?'filled':''}" style="height:${Math.max(4,x.n/5*82)}px" title="${x.n} of 5"></div><small>${x.label}</small></div>`).join('');
 $('skillProgress').innerHTML=habits.map(h=>{const n=Object.values(data.days).filter(d=>d[h.id]).length;const p=Math.min(100,Math.round(n/30*100));return `<div class="skill-row"><div class="skill-label"><b>${h.icon} ${h.title}</b><span>${n} days</span></div><div class="skill-track"><div class="skill-fill" style="width:${p}%"></div></div></div>`}).join('');
}
function renderJournalEntries(){
 const list=$('journalEntries'),entries=Object.entries(data.journal).sort((a,b)=>b[0].localeCompare(a[0]));
 if(!entries.length){list.innerHTML='<div class="entry-empty">Your reflections will appear here. Start with one honest sentence.</div>';return;}
 list.innerHTML=entries.map(([date,e])=>`<article class="entry"><div class="entry-top"><strong>${datePretty(date)} · ${escapeHtml(e.mood||'')}</strong><span><button class="text-button" data-edit="${date}">Edit</button> <button class="text-button danger-text" data-delete="${date}">Delete</button></span></div><p>${escapeHtml(e.text||'No written reflection.')}</p></article>`).join('');
 list.querySelectorAll('[data-edit]').forEach(b=>b.addEventListener('click',()=>{const d=b.dataset.edit,e=data.journal[d];$('journalDate').value=d;$('journalMood').value=e.mood;$('journalText').value=e.text;switchTab('journal');window.scrollTo({top:0,behavior:'smooth'});}));
 list.querySelectorAll('[data-delete]').forEach(b=>b.addEventListener('click',()=>{if(confirm('Delete this journal entry?')){delete data.journal[b.dataset.delete];save();renderAll();toast('Journal entry deleted.')}}));
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function renderAll(){renderHabits();renderHeader();renderProgress();renderJournalEntries();}
function switchTab(name){document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.tab===name));document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.id==='page-'+name));if(name==='journal'&&!$('journalDate').value)$('journalDate').value=todayKey();}
document.querySelectorAll('.tab').forEach(b=>b.addEventListener('click',()=>switchTab(b.dataset.tab)));
document.querySelectorAll('[data-workout]').forEach(b=>b.addEventListener('click',()=>{const name=b.dataset.workout;data.workouts[todayKey()]??={};const logged=!!data.workouts[todayKey()][name];if(logged){delete data.workouts[todayKey()][name];toast(name+' unlogged.')}else{data.workouts[todayKey()][name]=true;toast(name+' logged. Nice work!')}save();renderAll();}));
$('journalDate').value=todayKey();
$('saveJournal').addEventListener('click',()=>{const date=$('journalDate').value||todayKey(),text=$('journalText').value.trim(),mood=$('journalMood').value;if(!text){toast('Write a thought before saving.');$('journalText').focus();return;}data.journal[date]={text,mood,updatedAt:new Date().toISOString()};save();renderAll();$('journalStatus').textContent='Saved for '+datePretty(date)+'.';toast('Journal entry saved.');});
$('journalQuick').addEventListener('click',()=>{switchTab('journal');$('journalDate').value=todayKey();$('journalText').focus();});
$('timerMode').addEventListener('change',()=>{stopTimer();timerRemaining=Number($('timerMode').value)*60;timerTotal=timerRemaining;updateTimer();$('timerTitle').textContent=$('timerMode').selectedOptions[0].textContent;});
function updateTimer(){const m=Math.floor(timerRemaining/60),s=timerRemaining%60;$('timerDisplay').textContent=String(m).padStart(2,'0')+':'+String(s).padStart(2,'0');$('timerBar').style.width=((timerTotal-timerRemaining)/timerTotal*100)+'%';}
function stopTimer(){if(timerInterval)clearInterval(timerInterval);timerInterval=null;timerEnd=null;$('timerStart').textContent='Start focus';}
$('timerStart').addEventListener('click',()=>{if(timerInterval){stopTimer();toast('Timer paused.');return;}if(timerRemaining<=0){timerRemaining=timerTotal;updateTimer();}timerEnd=Date.now()+timerRemaining*1000;$('timerStart').textContent='Pause';timerInterval=setInterval(()=>{timerRemaining=Math.max(0,Math.ceil((timerEnd-Date.now())/1000));updateTimer();if(timerRemaining<=0){stopTimer();if($('timerMode').value!=='5'){data.focusMinutes=(data.focusMinutes||0)+Number($('timerMode').value);save();renderProgress();}toast('Session complete. Take a breath!');if('Notification'in window&&Notification.permission==='granted')new Notification('LEVEL UP',{body:'Your focus session is complete. Well done!'});}},250);});
$('timerReset').addEventListener('click',()=>{stopTimer();timerRemaining=Number($('timerMode').value)*60;timerTotal=timerRemaining;updateTimer();});
$('saveReminder').addEventListener('click',async()=>{const time=$('reminderTime').value;if(!time){toast('Choose a reminder time first.');return;}let status='Reminder saved in this browser.';if('Notification'in window){if(Notification.permission==='default'){try{await Notification.requestPermission()}catch(e){}}if(Notification.permission==='granted')status='Reminder time saved. Notifications are supported, but this page can only check while open; install/OS settings may affect delivery.';else status='Reminder time saved, but notifications are blocked. Enable them in browser settings.';}data.reminder={time,enabled:true};save();$('reminderStatus').textContent=status;toast('Reminder preference saved.');});
function checkReminder(){if(!data.reminder?.enabled)return;const now=new Date(),key=todayKey(),stamp=key+'-'+data.reminder.time;if(now.toTimeString().slice(0,5)===data.reminder.time&&localStorage.getItem('levelUpReminderLast')!==stamp){localStorage.setItem('levelUpReminderLast',stamp);if('Notification'in window&&Notification.permission==='granted')new Notification('Time to LEVEL UP',{body:'Take one small step for your goals today.'});else toast('Your daily reminder: take one small step today.');}}
setInterval(checkReminder,30000);
$('exportBtn').addEventListener('click',()=>{const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='level-up-backup-'+todayKey()+'.json';a.click();URL.revokeObjectURL(url);toast('Data backup downloaded.');});
$('resetBtn').addEventListener('click',()=>{if(confirm('This will permanently erase your checklist, journal, workouts, and progress from this device. Export a backup first if needed. Continue?')){localStorage.removeItem(STORE);data=load();renderAll();toast('App data reset.');}});
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();deferredInstallPrompt=e;$('installBtn').classList.remove('hidden');});
$('installBtn').addEventListener('click',async()=>{if(!deferredInstallPrompt){toast('Use your browser menu and choose Add to Home screen.');return;}deferredInstallPrompt.prompt();await deferredInstallPrompt.userChoice;deferredInstallPrompt=null;$('installBtn').classList.add('hidden');});
if('serviceWorker'in navigator&&location.protocol!=='file:'){window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));}
renderAll();updateTimer();
})();