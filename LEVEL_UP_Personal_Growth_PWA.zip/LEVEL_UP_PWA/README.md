# LEVEL UP — Personal Growth PWA

A mobile-first personal growth app with local-only storage.

## Features
- Daily checklist for communication, French, C + DSA, calisthenics, and running
- Daily completion ring, streaks, 7-day chart, skill practice totals
- Focus timer with completed-session tracking
- Workout logging
- Daily journal with mood, edit/delete
- Reminder preference and best-effort in-page notification
- Export data to JSON and reset local data
- PWA manifest, app icon, and service worker for offline use

## Run locally
Because service workers and PWA install require a secure context, use localhost or HTTPS:
1. Extract the ZIP.
2. In the folder, run `python -m http.server 8000`
3. Open `http://localhost:8000` in a browser.

## Install on Android
Host the folder on an HTTPS static host (for example GitHub Pages or Netlify), open the URL in Chrome, then use the browser menu → **Install app** or **Add to Home screen**.

## Data & limitations
Your entries are stored in this browser's localStorage. They are not synced across devices. Clearing browser site data may erase them, so use Export regularly. The timer is most reliable while the app remains open. Browser-based reminders cannot guarantee delivery when the app is closed; reliable scheduled push notifications would require a backend/push service.
